# Discord Bot template 🤖

Made with Typescript and Discord.js v14

Required : Typescript compiler

Thanks, Rorack and Dollar and Real.

```bash
# Run
npm run start
```
